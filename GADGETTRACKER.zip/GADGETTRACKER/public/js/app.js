/* public/js/app.js — Gadget Tracker */
'use strict';

const API = '../../app/api/gadgets.php';

// ── State ─────────────────────────────────────────────────────────────────
const state = { page: 1, limit: 15, search: '', invStatus: '', status: '', warehouse: '__ALL__', total: 0, totalPages: 1 };
let selectedIds   = new Set();
let deleteId      = null;
let toastTimeout  = null;
let searchDebounce = null;
let parsedCSVRows = [];

// ── DOM ───────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);

const tableBody     = $('table-body');
const tableLoading  = $('table-loading');
const recordCount   = $('record-count');
const searchInput   = $('search-input');
const clearSearch   = $('clear-search');
const filterInv     = $('filter-inv-status');
const filterStatus  = $('filter-status');
const limitSelect   = $('limit-select');
const prevBtn       = $('prev-btn');
const nextBtn       = $('next-btn');
const pageNumbers   = $('page-numbers');
const checkAll      = $('check-all');
const bulkBar       = $('bulk-bar');
const bulkCount     = $('bulk-count');
const bulkDeleteBtn = $('bulk-delete-btn');
const bulkDeselect  = $('bulk-deselect-btn');
const modalOverlay  = $('modal-overlay');
const toast         = $('toast');

// ── Panel switcher ────────────────────────────────────────────────────────
const PANELS = ['panel-form', 'panel-delete', 'panel-bulk-delete', 'panel-import'];

// ── Modal inert helper — prevents Tab from reaching page behind modal ────
function setPageInert(on) {
    // All direct children of <body> except the overlay get inert toggled
    document.querySelectorAll('body > *:not(#modal-overlay):not(#toast)').forEach(el => {
        if (on) {
            el.setAttribute('inert', '');
            el.setAttribute('aria-hidden', 'true');
        } else {
            el.removeAttribute('inert');
            el.removeAttribute('aria-hidden');
        }
    });
}

function showPanel(id) {
    PANELS.forEach(p => { document.getElementById(p).style.display = p === id ? 'flex' : 'none'; });
    // confirm-modal uses flex for centering; modal uses flex too
    if (id === 'panel-form') document.getElementById(id).style.display = 'flex';
    modalOverlay.style.display = 'flex';
    // Attach serial listeners the first time the form panel is shown
    if (id === 'panel-form') ensureSerialListeners();
    // Lock page content out of Tab order while modal is open
    setPageInert(true);
}

function closeOverlay() {
    modalOverlay.style.display = 'none';
    PANELS.forEach(p => { document.getElementById(p).style.display = 'none'; });
    deleteId = null;
    // Clear serial error state
    const si = $('f-serial'); const se = $('serial-error');
    if (si) si.style.borderColor = '';
    if (se) se.style.display = 'none';
    // Restore page Tab order
    setPageInert(false);
}

modalOverlay.addEventListener('click', e => { if (e.target === modalOverlay) closeOverlay(); });
document.addEventListener('keydown', e => {
    if (e.key === 'Escape') { closeOverlay(); return; }
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); searchInput.focus(); return; }

    // ── Focus trap: keep Tab inside the active modal panel ────────────────
    if (e.key === 'Tab' && modalOverlay.style.display !== 'none') {
        // Find the currently visible panel
        const activePanel = Array.from(modalOverlay.querySelectorAll(':scope > [id^="panel-"]'))
            .find(p => p.style.display !== 'none');
        if (!activePanel) return;

        const focusable = Array.from(activePanel.querySelectorAll(
            'a[href], button:not([disabled]):not([tabindex="-1"]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
        )).filter(el => el.offsetParent !== null); // visible only

        if (!focusable.length) return;
        const first = focusable[0];
        const last  = focusable[focusable.length - 1];

        if (e.shiftKey) {
            if (document.activeElement === first) { e.preventDefault(); last.focus(); }
        } else {
            if (document.activeElement === last)  { e.preventDefault(); first.focus(); }
        }
    }
});

// ── Load Table ────────────────────────────────────────────────────────────
async function loadTable() {
    tableLoading.style.display = 'flex';
    const params = new URLSearchParams({
        action: 'list', page: state.page, limit: state.limit,
        search: state.search, inventory_status: state.invStatus, status: state.status,
        warehouse: state.warehouse,
    });
    try {
        const json = await apiFetch(`${API}?${params}`);
        const { rows, total, total_pages } = json.data;
        state.total = total; state.totalPages = total_pages;
        renderRows(rows);
        renderPagination();
        recordCount.textContent = `${total.toLocaleString()} record${total !== 1 ? 's' : ''}`;
        updateActiveTabCount(total);
    } catch (e) {
        showToast('Failed to load: ' + e.message, 'error');
    } finally {
        tableLoading.style.display = 'none';
    }
}

function renderRows(rows) {
    selectedIds.clear();
    updateBulkBar();
    if (!rows.length) {
        tableBody.innerHTML = `<tr><td colspan="21" class="empty-cell">No records found.</td></tr>`;
        return;
    }
    tableBody.innerHTML = rows.map(r => `
    <tr data-id="${r.id}">
      <td class="col-check"><input type="checkbox" class="row-check" data-id="${r.id}" /></td>
      <td class="col-actions">
        <button class="action-edit"   tabindex="-1" onclick="openEdit(${r.id})">Edit</button>
        <button class="action-delete" tabindex="-1" onclick="openDelete(${r.id},'${esc(r.gadget)} — ${esc(r.user)}')">Del</button>
      </td>
      <td title="${esc(r.user)}">${esc(r.user)}</td>
      <td title="${esc(r.role)}">${esc(r.role)}</td>
      <td title="${esc(r.gadget)}">${esc(r.gadget)}</td>
      <td class="font-mono">${esc(r.serial_number)}</td>
      <td class="font-mono">${esc(r.warehouse_asset_tag)}</td>
      <td class="font-mono">${esc(r.asset_tag)}</td>
      <td class="font-mono">${esc(r.mac_address)}</td>
      <td class="pw-cell">${r.password ? '••••••' : '—'}</td>
      <td>${esc(r.warehouse_owner)}</td>
      <td title="${esc(r.remarks)}">${trunc(r.remarks, 28)}</td>
      <td>${esc(r.recent_responsible)}</td>
      <td title="${esc(r.description)}">${trunc(r.description, 28)}</td>
      <td class="font-mono">${esc(r.imei1)}</td>
      <td class="font-mono">${esc(r.imei2)}</td>
      <td>${invBadge(r.inventory_status)}</td>
      <td>${esc(r.warehouse)}</td>
      <td>${statusBadge(r.status)}</td>
      <td class="font-mono" style="font-size:.73rem">${fmtDate(r.created_at)}</td>
      <td class="font-mono" style="font-size:.73rem">${fmtDate(r.updated_at)}</td>
    </tr>`).join('');

    // row checkbox events
    tableBody.querySelectorAll('.row-check').forEach(cb => {
        cb.addEventListener('change', () => {
            const id = +cb.dataset.id;
            cb.checked ? selectedIds.add(id) : selectedIds.delete(id);
            cb.closest('tr').classList.toggle('row-selected', cb.checked);
            updateBulkBar();
            checkAll.indeterminate = selectedIds.size > 0 && selectedIds.size < rows.length;
            checkAll.checked = selectedIds.size === rows.length;
        });
    });
    checkAll.indeterminate = false;
    checkAll.checked = false;
}

// ── Check-all ─────────────────────────────────────────────────────────────
checkAll.addEventListener('change', () => {
    tableBody.querySelectorAll('.row-check').forEach(cb => {
        cb.checked = checkAll.checked;
        const id = +cb.dataset.id;
        checkAll.checked ? selectedIds.add(id) : selectedIds.delete(id);
        cb.closest('tr').classList.toggle('row-selected', cb.checked);
    });
    updateBulkBar();
});

function updateBulkBar() {
    const n = selectedIds.size;
    bulkBar.style.display = n > 0 ? 'block' : 'none';
    bulkCount.textContent = `${n} selected`;
}

bulkDeselect.onclick = () => {
    selectedIds.clear();
    tableBody.querySelectorAll('.row-check').forEach(cb => { cb.checked = false; cb.closest('tr').classList.remove('row-selected'); });
    checkAll.checked = checkAll.indeterminate = false;
    updateBulkBar();
};

// ── Bulk Delete ───────────────────────────────────────────────────────────
bulkDeleteBtn.onclick = () => {
    $('bulk-confirm-msg').textContent = `Permanently delete ${selectedIds.size} selected gadget(s)? This cannot be undone.`;
    showPanel('panel-bulk-delete');
};
$('bulk-cancel-btn').onclick = closeOverlay;

$('bulk-confirm-ok').onclick = async () => {
    const btn = $('bulk-confirm-ok');
    btn.disabled = true; btn.textContent = 'Deleting…';
    try {
        const json = await apiFetch(`${API}?action=bulk-delete`, {
            method: 'POST', body: JSON.stringify({ ids: [...selectedIds] }),
        });
        closeOverlay();
        selectedIds.clear(); updateBulkBar();
        showToast(json.message, 'success');
        if (state.page > 1 && state.total - json.data.deleted <= (state.page - 1) * state.limit) state.page--;
        loadWarehouses(); loadTable();
    } catch (e) {
        showToast(e.message, 'error');
    } finally {
        btn.disabled = false; btn.textContent = 'Delete All';
    }
};

// ── Single Delete ─────────────────────────────────────────────────────────
window.openDelete = (id, label) => {
    deleteId = id;
    $('confirm-msg').textContent = `Delete "${label}"? This cannot be undone.`;
    showPanel('panel-delete');
};
$('confirm-cancel').onclick = closeOverlay;

$('confirm-ok').onclick = async () => {
    const btn = $('confirm-ok');
    btn.disabled = true; btn.textContent = 'Deleting…';
    try {
        const json = await apiFetch(`${API}?action=delete`, {
            method: 'POST', body: JSON.stringify({ id: deleteId }),
        });
        closeOverlay();
        showToast(json.message, 'success');
        if (state.page > 1 && state.total - 1 <= (state.page - 1) * state.limit) state.page--;
        loadWarehouses(); loadTable();
    } catch (e) {
        showToast(e.message, 'error');
    } finally {
        btn.disabled = false; btn.textContent = 'Delete';
    }
};

// ── Add / Edit Form ───────────────────────────────────────────────────────
$('open-add-btn').onclick = () => openModal();
$('modal-close').onclick  = closeOverlay;
$('cancel-btn').onclick   = closeOverlay;

function openModal(data = null) {
    $('gadget-form').reset();
    $('f-id').value = '';
    $('modal-title').textContent = data ? 'Edit Gadget' : 'Add Gadget';
    $('submit-btn').textContent  = data ? 'Update Gadget' : 'Save Gadget';
    if (data) {
        $('f-id').value          = data.id;
        $('f-user').value        = data.user             || '';
        $('f-role').value        = data.role             || '';
        $('f-gadget').value      = data.gadget           || '';
        $('f-serial').value      = data.serial_number    || '';
        $('f-wh-asset-tag').value= data.warehouse_asset_tag || '';
        $('f-asset-tag').value   = data.asset_tag        || '';
        $('f-mac').value         = data.mac_address      || '';
        $('f-password').value    = data.password         || '';
        $('f-wh-owner').value    = data.warehouse_owner  || '';
        $('f-remarks').value     = data.remarks          || '';
        $('f-recent').value      = data.recent_responsible || '';
        $('f-description').value = data.description      || '';
        $('f-imei1').value       = data.imei1            || '';
        $('f-imei2').value       = data.imei2            || '';
        $('f-inv-status').value  = data.inventory_status || 'Active';
        $('f-warehouse').value   = data.warehouse        || '';
        $('f-status').value      = data.status           || 'Good';
    }
    showPanel('panel-form');
    $('f-user').focus();
}

window.openEdit = async id => {
    try {
        const json = await apiFetch(`${API}?action=get&id=${id}`);
        openModal(json.data);
    } catch (e) { showToast('Could not load: ' + e.message, 'error'); }
};

$('gadget-form').addEventListener('submit', async e => {
    e.preventDefault();
    const id     = $('f-id').value;
    const action = id ? 'update' : 'create';
    const btn    = $('submit-btn');
    const payload = {
        id: id ? +id : undefined,
        user:               $('f-user').value.trim(),
        role:               $('f-role').value.trim(),
        gadget:             $('f-gadget').value.trim(),
        serial_number:      $('f-serial').value.trim(),
        warehouse_asset_tag:$('f-wh-asset-tag').value.trim(),
        asset_tag:          $('f-asset-tag').value.trim(),
        mac_address:        $('f-mac').value.trim(),
        password:           $('f-password').value,
        warehouse_owner:    $('f-wh-owner').value.trim(),
        remarks:            $('f-remarks').value.trim(),
        recent_responsible: $('f-recent').value.trim(),
        description:        $('f-description').value.trim(),
        imei1:              $('f-imei1').value.trim(),
        imei2:              $('f-imei2').value.trim(),
        inventory_status:   $('f-inv-status').value,
        warehouse:          $('f-warehouse').value.trim(),
        status:             $('f-status').value,
    };
    btn.disabled = true; btn.textContent = 'Saving…';
    try {
        const json = await apiFetch(`${API}?action=${action}`, {
            method: 'POST', body: JSON.stringify(payload),
        });
        closeOverlay();
        showToast(json.message, 'success');
        loadWarehouses(); loadTable();
    } catch (e) {
        showToast(e.message, 'error');
    } finally {
        btn.disabled = false; btn.textContent = id ? 'Update Gadget' : 'Save Gadget';
    }
});

// Toggle password visibility
document.querySelector('.toggle-pw').onclick = () => {
    const f = $('f-password');
    f.type = f.type === 'password' ? 'text' : 'password';
};

// ── Serial number live duplicate check ─────────────────────────────────────
// Listeners are attached once (lazily) the first time the form panel opens.
let _serialListenersAttached = false;

function ensureSerialListeners() {
    if (_serialListenersAttached) return;
    _serialListenersAttached = true;

    const serialInput = $('f-serial');

    // Create error span under the serial input
    let serialError = $('serial-error');
    if (!serialError) {
        serialError = document.createElement('span');
        serialError.id = 'serial-error';
        serialError.style.cssText = 'font-size:.72rem;color:var(--red);margin-top:3px;display:none;';
        serialInput.parentNode.appendChild(serialError);
    }

    serialInput.addEventListener('blur', async () => {
        const sn  = serialInput.value.trim();
        const eid = $('f-id').value;
        serialError.style.display = 'none';
        serialInput.style.borderColor = '';
        if (!sn) return;
        try {
            const params = new URLSearchParams({ action: 'check-serial', serial: sn });
            if (eid) params.set('exclude_id', eid);
            const json = await apiFetch(`${API}?${params}`);
            if (json.data.exists) {
                serialError.textContent = `Serial "${sn}" already exists.`;
                serialError.style.display = 'block';
                serialInput.style.borderColor = 'var(--red)';
            }
        } catch (_) {}
    });

    serialInput.addEventListener('input', () => {
        serialError.style.display = 'none';
        serialInput.style.borderColor = '';
    });

    // Block form submit if serial error is visible
    $('gadget-form').addEventListener('submit', e => {
        const err = $('serial-error');
        if (err && err.style.display !== 'none') {
            e.stopImmediatePropagation();
            e.preventDefault();
            showToast('Fix the duplicate serial number before saving.', 'error');
        }
    }, true);
}

// ── CSV Import ────────────────────────────────────────────────────────────
const CSV_COLUMNS = ['user','role','gadget','serial_number','warehouse_asset_tag','asset_tag',
    'mac_address','password','warehouse_owner','remarks','recent_responsible','description',
    'imei1','imei2','inventory_status','warehouse','status'];

$('open-import-btn').onclick = () => {
    resetImport();
    showPanel('panel-import');
};
$('import-close').onclick    = closeOverlay;
$('import-cancel-btn').onclick = closeOverlay;

// Download template
$('download-template-btn').onclick = () => {
    const csv = CSV_COLUMNS.join(',') + '\n';
    const a   = Object.assign(document.createElement('a'), {
        href: 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv),
        download: 'gadgettracker_template.csv',
    });
    a.click();
};

// Drag & drop
const dropZone = $('drop-zone');
dropZone.addEventListener('dragover',  e => { e.preventDefault(); dropZone.classList.add('drag-over'); });
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
dropZone.addEventListener('drop', e => {
    e.preventDefault(); dropZone.classList.remove('drag-over');
    const file = e.dataTransfer.files[0];
    if (file) handleCSVFile(file);
});

$('csv-file-input').addEventListener('change', e => {
    if (e.target.files[0]) handleCSVFile(e.target.files[0]);
});

function handleCSVFile(file) {
    if (!file.name.endsWith('.csv') && file.type !== 'text/csv') {
        showToast('Please select a .csv file.', 'error'); return;
    }
    $('drop-filename').textContent = file.name;
    const reader = new FileReader();
    reader.onload = e => parseCSV(e.target.result);
    reader.readAsText(file);
}

function parseCSV(text) {
    const lines  = text.trim().split(/\r?\n/);
    if (lines.length < 2) { showToast('CSV is empty.', 'error'); return; }

    const headers = lines[0].split(',').map(h => h.trim().toLowerCase().replace(/\s+/g,'_'));
    const errors  = [];
    const seenSNs = new Set();
    parsedCSVRows = [];

    lines.slice(1).forEach((line, i) => {
        if (!line.trim()) return;
        const vals = parseCSVLine(line);
        const row  = {};
        headers.forEach((h, j) => { row[h] = (vals[j] || '').trim(); });

        const rowErrors = [];
        if (!row.gadget) rowErrors.push('gadget required');

        // Flag within-file serial duplicates immediately
        const sn = (row.serial_number || '').trim();
        if (sn !== '') {
            if (seenSNs.has(sn)) {
                rowErrors.push(`serial number "${sn}" is duplicated in this file`);
            } else {
                seenSNs.add(sn);
            }
        }

        row._rowNum = i + 2;
        row._errors = rowErrors;
        if (rowErrors.length) errors.push(`Row ${row._rowNum}: ${rowErrors.join(', ')}`);
        parsedCSVRows.push(row);
    });

    renderPreview(parsedCSVRows, errors);
    $('import-submit-btn').disabled = parsedCSVRows.filter(r => !r._errors.length).length === 0;
}

function parseCSVLine(line) {
    // Handles quoted fields
    const result = [];
    let cur = '', inQ = false;
    for (let i = 0; i < line.length; i++) {
        const c = line[i];
        if (c === '"') {
            if (inQ && line[i+1] === '"') { cur += '"'; i++; }
            else inQ = !inQ;
        } else if (c === ',' && !inQ) {
            result.push(cur); cur = '';
        } else cur += c;
    }
    result.push(cur);
    return result;
}

function renderPreview(rows, errors) {
    const preview = $('import-preview');
    const validCount = rows.filter(r => !r._errors.length).length;
    $('preview-count').textContent = `${validCount} valid row(s) of ${rows.length}`;
    const errBadge = $('preview-errors');
    if (errors.length) {
        errBadge.style.display = 'inline-block';
        errBadge.textContent   = `${errors.length} error(s)`;
    } else {
        errBadge.style.display = 'none';
    }

    // Headers: show first 8 cols + errors column for brevity
    const showCols = ['user','role','gadget','serial_number','inventory_status','warehouse','status'];
    $('preview-thead').innerHTML = showCols.map(c => `<th>${c}</th>`).join('') + '<th>Issues</th>';
    $('preview-tbody').innerHTML = rows.map(r => {
        const hasErr = r._errors.length > 0;
        return `<tr class="${hasErr ? 'row-error' : ''}">
            ${showCols.map(c => `<td title="${esc(r[c])}">${trunc(r[c], 20)}</td>`).join('')}
            <td class="row-error-msg">${r._errors.join(', ') || '—'}</td>
        </tr>`;
    }).join('');
    preview.style.display = 'block';
}

function resetImport() {
    parsedCSVRows = [];
    $('drop-filename').textContent = 'No file chosen';
    $('csv-file-input').value      = '';
    $('import-preview').style.display = 'none';
    $('import-submit-btn').disabled   = true;
}

$('import-submit-btn').onclick = async () => {
    const validRows = parsedCSVRows.filter(r => !r._errors.length);
    if (!validRows.length) return;

    const btn = $('import-submit-btn');
    btn.disabled = true; btn.textContent = 'Importing…';
    try {
        const json = await apiFetch(`${API}?action=import`, {
            method: 'POST', body: JSON.stringify({ rows: validRows }),
        });
        closeOverlay();
        resetImport();
        const type = json.data.errors?.length ? 'error' : 'success';
        showToast(json.message, type);
        loadWarehouses(); loadTable();
    } catch (e) {
        showToast(e.message, 'error');
    } finally {
        btn.disabled = false; btn.textContent = 'Import Records';
    }
};

// ── Pagination ────────────────────────────────────────────────────────────
prevBtn.onclick   = () => { if (state.page > 1) { state.page--; loadTable(); } };
nextBtn.onclick   = () => { if (state.page < state.totalPages) { state.page++; loadTable(); } };
limitSelect.onchange = () => { state.limit = +limitSelect.value; state.page = 1; loadTable(); };

window.goPage = p => { state.page = p; loadTable(); };

function renderPagination() {
    prevBtn.disabled = state.page <= 1;
    nextBtn.disabled = state.page >= state.totalPages;
    const tp = state.totalPages, cp = state.page;
    const pages = [];
    if (tp <= 7) { for (let i = 1; i <= tp; i++) pages.push(i); }
    else {
        pages.push(1);
        if (cp > 3) pages.push('…');
        for (let i = Math.max(2, cp-1); i <= Math.min(tp-1, cp+1); i++) pages.push(i);
        if (cp < tp-2) pages.push('…');
        pages.push(tp);
    }
    pageNumbers.innerHTML = pages.map(p =>
        p === '…'
          ? `<span class="pg-num ellipsis">…</span>`
          : `<button class="pg-num ${p===cp?'active':''}" tabindex="-1" onclick="goPage(${p})">${p}</button>`
    ).join('');
}

// ── Search & Filter ───────────────────────────────────────────────────────
searchInput.addEventListener('input', () => {
    clearSearch.style.display = searchInput.value ? 'block' : 'none';
    clearTimeout(searchDebounce);
    searchDebounce = setTimeout(() => { state.search = searchInput.value.trim(); state.page = 1; loadTable(); }, 380);
});
clearSearch.onclick = () => { searchInput.value = ''; clearSearch.style.display = 'none'; state.search = ''; state.page = 1; loadTable(); };
filterInv.onchange    = () => { state.invStatus = filterInv.value;    state.page = 1; loadTable(); };
filterStatus.onchange = () => { state.status    = filterStatus.value; state.page = 1; loadTable(); };

// ── Helpers ───────────────────────────────────────────────────────────────
function esc(v) {
    if (!v) return '—';
    return String(v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function trunc(v, n) { if (!v) return '—'; return v.length > n ? esc(v.slice(0,n))+'…' : esc(v); }
function fmtDate(v)  { if (!v) return '—'; return v.replace('T',' ').slice(0,16); }

function invBadge(v) {
    const map = { 'Active':'badge-active','In Stock':'badge-in-stock','In Repair':'badge-in-repair','Retired':'badge-retired','Lost':'badge-lost','Disposed':'badge-disposed' };
    return `<span class="badge ${map[v]||''}">${esc(v)}</span>`;
}
function statusBadge(v) {
    const map = { 'Good':'badge-good','Damaged':'badge-damaged'};
    return `<span class="badge ${map[v]||''}">${esc(v)}</span>`;
}

async function apiFetch(url, opts = {}) {
    const res  = await fetch(url, { headers: { 'Content-Type': 'application/json' }, ...opts });
    const json = await res.json();
    if (!json.success) throw new Error(json.message);
    return json;
}

function showToast(msg, type = 'success') {
    clearTimeout(toastTimeout);
    toast.textContent   = msg;
    toast.className     = `toast ${type}`;
    toast.style.display = 'block';
    toastTimeout = setTimeout(() => { toast.style.display = 'none'; }, 3400);
}

// ── Warehouse Tabs ───────────────────────────────────────────────────────
async function loadWarehouses() {
    try {
        const json = await apiFetch(`${API}?action=warehouses`);
        renderWarehouseTabs(json.data);
    } catch (e) {
        console.warn('Could not load warehouses:', e.message);
    }
}

function renderWarehouseTabs(warehouses) {
    const tabs = document.getElementById('wh-tabs');
    // Remove old dynamic tabs (keep only the "All" tab)
    tabs.querySelectorAll('.wh-tab[data-dynamic]').forEach(t => t.remove());

    warehouses.forEach(({ warehouse, cnt }) => {
        const btn = document.createElement('button');
        btn.className = 'wh-tab';
        btn.dataset.warehouse = warehouse;
        btn.dataset.dynamic = '1';
        btn.tabIndex = -1;  // exclude from keyboard Tab order
        btn.innerHTML = `
            <span class="wh-tab-label">${escHtml(warehouse)}</span>
            <span class="wh-tab-count">${cnt}</span>
        `;
        btn.addEventListener('click', () => switchTab(warehouse));
        tabs.appendChild(btn);
    });

    // Restore active state
    highlightActiveTab();
}

function switchTab(warehouse) {
    state.warehouse = warehouse;
    state.page = 1;
    highlightActiveTab();
    loadTable();
}

function highlightActiveTab() {
    document.querySelectorAll('.wh-tab').forEach(t => {
        t.classList.toggle('active', t.dataset.warehouse === state.warehouse);
    });
}

function updateActiveTabCount(total) {
    // Update the count badge on the active tab
    const activeTab = document.querySelector(`.wh-tab[data-warehouse="${CSS.escape(state.warehouse)}"]`);
    if (activeTab) {
        const badge = activeTab.querySelector('.wh-tab-count');
        if (badge) badge.textContent = total.toLocaleString();
    }
}

function escHtml(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// Wire the "All Warehouses" tab
document.getElementById('wh-tabs').querySelector('.wh-tab[data-warehouse="__ALL__"]')
    .addEventListener('click', () => switchTab('__ALL__'));

// ── Init ──────────────────────────────────────────────────────────────────
loadWarehouses();
loadTable();


